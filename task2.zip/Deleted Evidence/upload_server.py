from flask import Flask, request
app = Flask(__name__)
@app.route('/upload', methods=['POST'])
def upload():
    for name, f in request.files.items():
        f.save(f.filename)
    return "OK", 200
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000)

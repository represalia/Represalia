#!/usr/bin/env bash
set -e
WORKDIR="$(pwd)/ctf_build"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

# check files copied
cp ../image.jpg . 2>/dev/null || cp ../image.png . 2>/dev/null || true
cp ../secret.zip . 2>/dev/null || true

# create upload server
cat > upload_server.py <<'PY'
from flask import Flask, request
app = Flask(__name__)
@app.route('/upload', methods=['POST'])
def upload():
    for name, f in request.files.items():
        f.save(f.filename)
    return "OK", 200
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000)
PY

PCAP_FILE="$(pwd)/challenge.pcap"
sudo pkill -f "tcpdump -i lo" || true
sudo tcpdump -i lo -w "$PCAP_FILE" port 8000 >/dev/null 2>&1 &
TCPDUMP_PID=$!
sleep 1

python3 upload_server.py &
SERVER_PID=$!
sleep 1

# send files via multipart/form
curl -s -F "file1=@image.jpg" -F "file2=@secret.zip" http://127.0.0.1:8000/upload

sleep 1
kill $SERVER_PID || true
sudo kill $TCPDUMP_PID || true

echo "PCAP saved to: $PCAP_FILE"
ls -l "$PCAP_FILE"
